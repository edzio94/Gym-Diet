/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gymgenerator.exercises;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lukasz
 */
public class TrapsExercises extends ExercisesBase{        
        public TrapsExercises()
        {
             exercises = new ArrayList<>();
             exercises.add(new Attributes("Szrugsy",0,0,0,0,0,0,10,false));
        }
}
